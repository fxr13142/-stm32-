#include "stm32f10x.h"
#include "Delay.h"                 
#include "oled.h"
#include "adc.h"
#include "temperature.h"
//#include "gettem.h"
int n=0;
int allnum=0;
uint16_t sound;
int b=0;
int g=0;
int t=0;
int a,b,c,d,e;
int time=7;

uint16_t xiaoshu;
uint16_t result;
uint16_t zhengshu;
uint16_t shidu;
uint16_t shengyin;


void beep(int time1,int time2,int ti,int rt)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	OLED_Init();
	
		OLED_Clear();
	
	for(int i=0;i<ti-(rt*i*i);i++)
	{
	
		GPIO_SetBits(GPIOA, GPIO_Pin_9);
		Delay_ms(time1);
		GPIO_ResetBits(GPIOA, GPIO_Pin_9);
		Delay_ms(1);
	}
	
}

void beep();

int main(void)
{
	//beep(1,3);
	
	OLED_Init();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	OLED_Clear();
	while(1)
	{
		a=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3);
		
		OLED_ShowCHinese(1,0,7);
		OLED_ShowCHinese(17,0,8);
		OLED_ShowCHinese(33,0,9);
		OLED_ShowCHinese(49,0,10);
		
		OLED_ShowCHinese(1,3,7);
		OLED_ShowCHinese(17,3,8);
		OLED_ShowCHinese(33,3,11);
		OLED_ShowCHinese(49,3,12);
		
		OLED_ShowNum(65,0,time,2,16);
		OLED_ShowNum(65,3,1,2,16);
		OLED_ShowString(81,0,"ms",16);
		OLED_ShowString(81,3,"ms",16);
		
		OLED_ShowString(110,0,"OP",2);
		OLED_ShowString(0,7,"By",2);
		OLED_ShowCHinese(15,6,13);
		OLED_ShowCHinese(31,6,14);
		OLED_ShowCHinese(47,6,15);
		OLED_ShowCHinese(63,6,16);
		OLED_ShowCHinese(79,6,17);
		OLED_ShowCHinese(95,6,18);
		OLED_ShowCHinese(111,6,19);
		
		
		if(a==1)
		{
			OLED_Clear();
			OLED_ShowString(5,2,"playing...",16);
			beep(time,1,9600,5);
			OLED_ShowString(5,2,"over",16);
			Delay_ms(500);
			if(time>1)
			{
				time=time-1;
			}
			else
			{
				time=7;
			}
			OLED_Clear();
			
		}
		
		
	
		
	
	}
	
	
}















/*

void gettem1 (void)
{
	ADC_init();
	//while(1)
	//{
		
		OLED_Init();
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		OLED_ShowNum(0,0,getadc(),9,16);
	//}
	OLED_Init();
	OLED_Clear();
	OLED_ShowNum(0,6,1,1,16);
	
	//shidu
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	shidu=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9);
	
	
	

	OLED_ShowCHinese(0,0,1);
	OLED_ShowCHinese(16,0,2);
	OLED_ShowCHinese(32,0,0);
	
	OLED_ShowCHinese(0,4,5);
	OLED_ShowCHinese(16,4,6);
	OLED_ShowCHinese(32,4,0);
	
	result=Get_Temperature();
	xiaoshu=result&15;
	zhengshu=(result>>4)&127;
	OLED_ShowNum(48,0,zhengshu,2,16);
	OLED_ShowChar(64,0,'.',16);
	OLED_ShowNum(68,0,xiaoshu,1,16);
	OLED_ShowNum(48,4,shidu,2,16);
	if(shidu==0)
	{
		OLED_ShowString(64,4,"wet",16);
	}
	else
	{
		
			OLED_ShowString(64,4,"med",16);
	}
		
	
	if(zhengshu<=15)
	{
		OLED_ShowString(80,0,"cold",16);
	}
	if(zhengshu>15)
	{
		if(zhengshu<=31)
		{
			OLED_ShowString(80,0,"ok||",16);
		}
		else
		{
			OLED_ShowString(80,0,"hot|",16);
		}
			
	}
	if(zhengshu>35)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_ResetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		GPIO_SetBits(GPIOA, GPIO_Pin_4);
		Delay_s(1);
		
	}
	else
	{
		if(shidu==0)
		{
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
			GPIO_InitTypeDef GPIO_InitStructure;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
			GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5;
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOA,&GPIO_InitStructure);
			GPIO_ResetBits(GPIOA, GPIO_Pin_5);
			Delay_s(5);
			GPIO_SetBits(GPIOA, GPIO_Pin_5);
			Delay_s(1);
		}
	}
}




void gettem2 (void)
{
	int a=5;
	ADC_init();
	//while(1)
	//{
		
		OLED_Init();
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		OLED_ShowNum(0,0,getadc(),9,16);
	//}
	OLED_Init();
	OLED_Clear();
	OLED_ShowNum(0,5,2,1,16);
	
	//shidu
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	shidu=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9);
	
	//shengyin
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	shengyin=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_10);
	
	//show
	
	OLED_ShowCHinese(0,0,5);
	OLED_ShowCHinese(16,0,6);
	OLED_ShowCHinese(32,0,0);
	
	OLED_ShowCHinese(0,2,3);
	OLED_ShowCHinese(16,2,4);
	OLED_ShowCHinese(32,2,0);
	
	OLED_ShowNum(48,0,shidu,1,16);
	OLED_ShowNum(40,2,shengyin,2,16);
	
	
	if(shengyin==0)
	{
		OLED_ShowString(64,2,"loud",16);
	}
	else
	{
		OLED_ShowString(64,2,"ok||",16);
	}
	
	if(shidu==0)
	{
		OLED_ShowString(64,4,"wet",16);
	}
	else
	{
		
			OLED_ShowString(64,4,"med",16);
	}
	
	if(shidu==0 )
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		GPIO_ResetBits(GPIOA, GPIO_Pin_3);
		Delay_s(5);
		GPIO_SetBits(GPIOA, GPIO_Pin_3);
		Delay_s(1);
	}
	else{
		if(shengyin==1)
		{
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
			GPIO_InitTypeDef GPIO_InitStructure;
			GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
			GPIO_InitStructure.GPIO_Pin=GPIO_Pin_7;
			GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOA,&GPIO_InitStructure);
			GPIO_ResetBits(GPIOA, GPIO_Pin_7);
			Delay_s(5);
			GPIO_SetBits(GPIOA, GPIO_Pin_7);
			Delay_s(1);
		}
	}
}



void gettem1();
void gettem2();
	




int main(void)
{	
	
	
	ADC_init();
	
	OLED_Init();
	
	while(1)
	{
		OLED_Clear();
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		g=GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12);

		if(g==0)
		{
			
			if(n%2==0)
			{
				
				for(t=0;t<17;t++)
				{
					
					gettem1();
				}
				n++;
			}
			else
			{
				for(t=0;t<17;t++)
				{
					
					
					gettem2();
					
				}
				n++;
			}
		}
	}
}



*/
























	
	
	/*
	ADC_init();
	OLED_Init();
	OLED_Clear();
	
	
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	//GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	//
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_ResetBits(GPIOA, GPIO_Pin_4);
	Delay_s(1);
	GPIO_SetBits(GPIOA, GPIO_Pin_4);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_3);
	Delay_ms(500);
	GPIO_ResetBits(GPIOA, GPIO_Pin_3);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_ResetBits(GPIOA, GPIO_Pin_5);
	Delay_ms(500);
	GPIO_SetBits(GPIOA, GPIO_Pin_5);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_ResetBits(GPIOA, GPIO_Pin_7);
	Delay_ms(500);
	GPIO_SetBits(GPIOA, GPIO_Pin_7);
	*/
	
	
	
	/*
	
	
	
	
	
	
	
	
					
					
	if(getadc()==1)
	{
		if(n%2==0)
		{
			gettem1();
			if(zhengshu>35)
			{
				RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
				GPIO_InitTypeDef GPIO_InitStructure;
				GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
				GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
				GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
				GPIO_Init(GPIOA,&GPIO_InitStructure);
				GPIO_ResetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_SetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_ResetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_SetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_ResetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_SetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_ResetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_SetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_ResetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
				GPIO_SetBits(GPIOA, GPIO_Pin_4);
				Delay_s(1);
			}
			else
			{
				if(shidu>3000)
				{
					RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
					GPIO_InitTypeDef GPIO_InitStructure;
					GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
					GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
					GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
					GPIO_Init(GPIOA,&GPIO_InitStructure);
					GPIO_ResetBits(GPIOA, GPIO_Pin_3);
					Delay_s(5);
					GPIO_SetBits(GPIOA, GPIO_Pin_3);
					Delay_s(1);
					GPIO_ResetBits(GPIOA, GPIO_Pin_3);
					Delay_s(5);
					GPIO_SetBits(GPIOA, GPIO_Pin_3);
				}
			}
			n++;
		}
		else
		{
			gettem2();
			if(shidu>3000)
			{
				RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
				GPIO_InitTypeDef GPIO_InitStructure;
				GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;//red
				GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5;
				GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
				GPIO_Init(GPIOA,&GPIO_InitStructure);
				GPIO_ResetBits(GPIOA, GPIO_Pin_5);
				Delay_s(5);
			}
			else{
				if(shengyin<500)
				{
					RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
					GPIO_InitTypeDef GPIO_InitStructure;
					GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
					GPIO_InitStructure.GPIO_Pin=GPIO_Pin_7;
					GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
					GPIO_Init(GPIOA,&GPIO_InitStructure);
					GPIO_ResetBits(GPIOA, GPIO_Pin_7);
					Delay_ms(300);
					GPIO_SetBits(GPIOA, GPIO_Pin_7);
					Delay_ms(300);
				}
			}
			n++;
		}
	}
	
	
	
	
	
*/
	
	
	
	
	
	
	
	
	
	
	/*while(1)
	{
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
			GPIO_Init(GPIOA,&GPIO_InitStructure);
		GPIO_SetBits(GPIOA, GPIO_Pin_3);
	}*/
	//if(getadc()==1)
	//{
		//if(b%2==0)
		//{
			//n++;
			//gettem();
		//}
	//}
	
	
	//microsetup();
	//sound=loop();
	//OLED_ShowNum(0,0,sound,16,16);
	//while(1)
	//{
	//	gettem();
	//}
	/*RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	//GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	while(1)
	{
		result=Get_Temperature();
		xiaoshu=result&15;
		zhengshu=(result>>4)&127;
		OLED_ShowNum(3,10,zhengshu,2,16);
		OLED_ShowChar(18,10,'.',16);
		OLED_ShowNum(22,10,xiaoshu,2,16);
	}
	for(i=0;i<96;i++)
	{
		//OLED_ShowCHinese(7*i,0,14);
		//OLED_ShowNum(7*i+17,0,34,2,16);
		//Delay_s(1);
		OLED_ShowCHinese(i,0,14);
		OLED_ShowNum(i+17,0,34,2,16);
		Delay_ms(10);
	}
	OLED_Clear();
	OLED_ShowCHinese(i,0,14);
	OLED_ShowNum(i+17,0,34,2,16);
	Delay_s(14);
	OLED_Clear();
	
	

	
	//OLED_ShowNum(1,1,0,1,16);
	//OLED_ShowString(1,1,"hello");
	while(1)
	{
	
	}*/
	/*RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;													//���ö˿�
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;								//��������ٶ�
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_13;
	GPIO_Init(GPIOC,&GPIO_InitStructure);														//��ʼ�����
	while(1)
	{
		GPIO_WriteBit(GPIOA,GPIO_Pin_9,Bit_RESET);
		GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_SET);	
		Delay_ms(500);
		GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_RESET);
		Delay_ms(500);
	}
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	ADC_init();
	OLED_Init();
	GPIO_InitTypeDef GPIO_InitStructure;														//�����ṹ��
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;								//�л����ģʽ
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_13;													//���ö˿�
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;								//��������ٶ�
	GPIO_Init(GPIOC,&GPIO_InitStructure);														//��ʼ������
	GPIO_WriteBit(GPIOC,GPIO_Pin_1,Bit_SET);												//����Ϊ�ߵ�
	GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_SET);	
	Delay_ms(500);
	GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_RESET);	
	Delay_ms(500);
	while(1)
	{
		OLED_ShowNum(1,1,1,1);																	//��ʾ
		Delay_ms(500);
		OLED_ShowNum(1,1,2,1);																	//��ʾ
		Delay_ms(500);
		OLED_ShowNum(1,1,3,1);																	//��ʾ
		Delay_ms(500);
		OLED_ShowNum(1,1,4,1);																	//��ʾ
		Delay_ms(500);
		GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_RESET);	
		Delay_ms(500);
		GPIO_WriteBit(GPIOC,GPIO_Pin_13,Bit_SET);	
		Delay_ms(500);
	}
		result=Get_Temperature();
		xiaoshu=result&15;
		zhengshu=(result>>4)&127;
		OLED_ShowNum(3,1,zhengshu+3,2);
		OLED_ShowChar(3,3,'.');
		OLED_ShowNum(3,4,xiaoshu,2);
		OLED_ShowNum(2,1,allnum,5);
		OLED_ShowNum(4,1,n,5);
		
		allnum++;

		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;													//���ö˿�
		GPIO_Init(GPIOA,&GPIO_InitStructure);														//���ö˿�
		a=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_13;												//���ö˿�
		GPIO_Init(GPIOC,&GPIO_InitStructure);														//���ö˿�
		b=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_15;													//���ö˿�
		GPIO_Init(GPIOC,&GPIO_InitStructure);														//���ö˿�
		c=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6;													//���ö˿�
		GPIO_Init(GPIOA,&GPIO_InitStructure);														//���ö˿�
		d=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;													//���ö˿�
		GPIO_Init(GPIOB,&GPIO_InitStructure);														//���ö˿�
		e=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;													//���ö˿�
		GPIO_Init(GPIOB,&GPIO_InitStructure);														//���ö˿�
		f=getadc();
		
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;													//���ö˿�
		GPIO_Init(GPIOB,&GPIO_InitStructure);	
		int soundLevel=getadc();
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;										//����ģʽ
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_7;													//���ö˿�
		GPIO_Init(GPIOB,&GPIO_InitStructure);	
		h=getadc();
		
		OLED_ShowNum(1,1,1,8);
		OLED_ShowNum(1,1,b,8);
		OLED_ShowNum(1,1,c,8);
		OLED_ShowNum(1,1,d,8);
		OLED_ShowNum(1,1,e,8);*/
		
	

