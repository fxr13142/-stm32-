/*
#include "stm32f10x.h"
#include "Delay.h"                 
#include "oled.h"
#include "adc.h"
#include "temperature.h"

uint16_t xiaoshu;
uint16_t result;
uint16_t zhengshu;
uint16_t shidu;
uint16_t shengyin;


void gettem (void)
{
	ADC_init();
	//while(1)
	//{
		/*
		OLED_Init();
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
		GPIO_InitTypeDef GPIO_InitStructure;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
		GPIO_Init(GPIOA,&GPIO_InitStructure);
		OLED_ShowNum(0,0,getadc(),9,16);*/
	//}
	/*OLED_Clear();
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	shidu=getadc();
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_10;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	shengyin=getadc();
	
	OLED_ShowCHinese(0,0,14);
	result=Get_Temperature();
	xiaoshu=result&15;
	zhengshu=(result>>4)&127;
	OLED_ShowNum(17,0,zhengshu,2,16);
	OLED_ShowChar(33,0,'.',16);
	OLED_ShowNum(37,0,xiaoshu,1,16);
	OLED_ShowNum(0,10,shidu,7,16);
	OLED_ShowNum(0,20,shengyin,7,16);
	if(zhengshu<=15)
	{
		OLED_ShowString(69,0,"cold",16);
	}
	if(zhengshu>15)
	{
		if(zhengshu<=31)
		{
			OLED_ShowString(69,0,"ok||",16);
		}
		else
		{
			OLED_ShowString(69,0,"hot|",16);
		}
			
	}
	Delay_s(13);
	
	
	

	
	
	
	
}
*/