#ifndef __TEMPERATURE_H
#define __TEMPERATURE_H 
uint8_t Tpt_Init(void);
uint8_t Write_Bit(uint8_t value);
void Write_Byte(uint8_t byte);
uint8_t Read_Byte(void);
uint16_t Get_Temperature(void);
#endif

