#include "stm32f10x.h"
#include "Delay.h"                 
#include "oled.h"
#include "adc.h"
#include "temperature.h"

void showch (int x,int y,int chn)
{
	OLED_ShowCHinese(x,y,chn);
}
