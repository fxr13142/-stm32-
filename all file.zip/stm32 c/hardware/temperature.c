#include "stm32f10x.h"                  // Device header
#include "Delay.h"

#define DQ_Port GPIOB
#define DQ_PIN GPIO_Pin_9
#define DQ_H GPIO_SetBits(DQ_Port,DQ_PIN)
#define DQ_L GPIO_ResetBits(DQ_Port,DQ_PIN)

static void DQ_SET_OUT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=DQ_PIN;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(DQ_Port,&GPIO_InitStructure);
}

static void DQ_SET_IN(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=DQ_PIN;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(DQ_Port,&GPIO_InitStructure);
}

static uint8_t Check(void)
{
	uint16_t cnt=0;
	DQ_SET_IN();
	while((GPIO_ReadInputDataBit(DQ_Port,DQ_PIN)==1) && cnt<90)
	{
		Delay_us(1);
		cnt++;
	}
	if (cnt>=90) return 0;
	cnt=0;
	while((GPIO_ReadInputDataBit(DQ_Port,DQ_PIN)==0) && cnt<240)
	{
		Delay_us(1);
		cnt++;
	}
	if(cnt>=240)
	{
		return 0;
	}
		return 1;
}

uint8_t Tpt_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	DQ_SET_OUT();
	DQ_H;
	//Delay_s(1);
	DQ_L;
	Delay_us(480);
	DQ_H;
	Delay_us(15);
	if (Check()==1) 
	{	
		return 1;
	}
	else
	{	
		return 0;
	}
}

static void Write_Bit(uint8_t value)
{
	DQ_SET_OUT();
	DQ_L;
	Delay_us(10);
	if(value==1)
	{
		DQ_H;	
	}
	else if(value==0)
	{
		DQ_L;
	}
	Delay_us(50);
	DQ_H;
	Delay_us(2);
}

void Write_Byte(uint8_t byte)
{
	uint8_t bit=0;
	for(int i=0;i<8;i++)
	{
		bit=byte & 0x01;
		byte=byte>>1;
		Write_Bit(bit);
	}
}
	

static uint8_t Read_Bit(void)
{
	uint8_t value=0;
	
	DQ_SET_OUT();
	DQ_L;
	Delay_us(2);
	DQ_H;
	Delay_us(13);
	DQ_SET_IN();
	if (GPIO_ReadInputDataBit(DQ_Port,DQ_PIN)==0)
	{
		value=0;
	}
	else
	{
		value=1;
	}
	Delay_us(50);
	return value;
}

uint8_t Read_Byte(void)
{
	uint8_t value=0,temp=0;
	for(int i=0;i<8;i++)
	{
		temp=Read_Bit();
		value= value | temp<<i;
	}
	return value;
}

int16_t Get_Temperature(void)
{
	uint8_t value_L;
	uint8_t value_H;
	int16_t value;
	float value_f;
	Tpt_Init();
	Write_Byte(0xCC);
	Write_Byte(0x44);
	while(Read_Byte()!=0xFF){}
	Tpt_Init();
	Write_Byte(0xCC);
	Write_Byte(0xBE);
	value_L=Read_Byte();
	value_H=Read_Byte();
	value=value_H<<8|value_L;
	return value;
}
