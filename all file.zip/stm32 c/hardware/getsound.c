#include "stm32f10x.h"
#include "Delay.h"                 
#include "oled.h"
#include "adc.h"
#include "temperature.h"
#include "sys.h"
#include "stdlib.h"

const int microphonePin = A0;
int baselineValue = 620;

void microsetup()
{
	Serial.begin(9600);
}

void loop()
{
	int sensorValue = analogRead(microphonePin);
	int soundLevel = sensorValue - baselineValue;
	if(soundLevel<0)
	{
		soundLevel=0;
	}
	Serial.print("Sound level:");
	Serial.println(soundLevel);
	Delay_ms(100);
}

