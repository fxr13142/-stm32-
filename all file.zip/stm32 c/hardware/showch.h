void showch (int,int,int);
