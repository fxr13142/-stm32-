void gettem (void);
